<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Str;

class MigrationCreate extends Command
{
    protected $signature = 'migration:create {table} {fields}';
    protected $description = 'Create migration';

    public function handle()
    {
    	// Receber variáveis
        $table = $this->argument('table');
        $fields = $this->argument('fields');
        $tableUc = Str::of($table)->ucfirst();

        // Definir arquivo de stub
        $stub = app_path('Console/Commands/stubs/migration.stub');
        
		// Open the file to get existing content
		$string = file_get_contents($stub);
		
		$fields = explode(',', $fields);
		$flds = '';
		foreach($fields as $field){
			$flds .= "\$table->string('$field');\n\t\t\t";
		}

		$string = str_replace('{{tableUc}}', $tableUc, $string);
		$string = str_replace('{{table}}', $table, $string);
		$string = str_replace('{{fieldsMig}}', $flds, $string);		
		$name = date('Y_m_d_His').'_create_'.$table.'_table.php';
		$mig = database_path('migrations/'.$name);		
		file_put_contents($mig, $string);

		$this->info('=> Migration criada com sucesso');	

		// php artisan migration:create clients name,email
    }
}
