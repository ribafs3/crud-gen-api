<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;

class ControllerCreate extends Command
{
    protected $signature = 'controller:create {table}';
    protected $description = 'Create controller';

    public function handle()
    {
    	// Receber variáveis
        $table = $this->argument('table');
        $tableSing = Str::of($table)->singular();
        $tableUcSing = Str::of($tableSing)->ucfirst();

        // Definir arquivo de stub
        $stub = app_path('Console/Commands/stubs/controller.stub');

		// Open the file to get existing content
		$string = file_get_contents($stub);

		$string = str_replace('{{table}}', $table, $string);
		$string = str_replace('{{tableSing}}', $tableSing, $string);
		$string = str_replace('{{tableUcSing}}', $tableUcSing, $string);
		
		$dirAcl = app_path('Http/Controllers/');
		if(!File::exists($dirAcl)){
			$dirAcl = File::makeDirectory($dirAcl, 0755, true);
		}
		
		$dirAcl .= $tableUcSing.'Controller.php';
	
		file_put_contents($dirAcl, $string);
		$this->info('=> Controller criado com sucesso');
		
		// Chamar com
		// php artisan controller:create customers
    }
}
