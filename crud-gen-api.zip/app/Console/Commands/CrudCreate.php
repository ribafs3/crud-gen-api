<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;

class CrudCreate extends Command
{
    protected $signature = 'crud:api {table} {fields}';

    protected $description = 'Create CRUD API';

    public function handle()
    {
        $table = $this->argument('table');
        $fields = $this->argument('fields');

        Artisan::call("migration:create $table $fields");
        Artisan::call("model:create $table $fields");
        Artisan::call("controller:create $table");        
        Artisan::call("route:create $table");
        
        $this->info('=> CRUD criado com sucesso');
    }
}
